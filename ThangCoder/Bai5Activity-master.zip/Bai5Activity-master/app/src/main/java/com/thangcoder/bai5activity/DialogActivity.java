package com.thangcoder.bai5activity;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Administrator on 18/09/2016.
 */
public class DialogActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
